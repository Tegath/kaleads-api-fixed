"""
Orchestrateur de campagne (Atomic Agents v2).
"""

from src.orchestrator.campaign_orchestrator_v2 import CampaignOrchestrator

__all__ = ["CampaignOrchestrator"]
