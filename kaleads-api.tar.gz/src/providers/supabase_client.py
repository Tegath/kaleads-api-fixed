"""
Supabase client for loading client context.

Tables:
- clients: Client info + PCI (Profil Client Ideal)
- personas: Target personas per client
- competitors: Competitor info per client
- case_studies: Case study results per client
- scraping_cache: Website scraping cache
"""

import os
from typing import Optional, Dict, List, Any
from pydantic import BaseModel
from datetime import datetime


class ClientPCI(BaseModel):
    """Profil Client Ideal (Ideal Customer Profile)."""
    industry: List[str] = []
    company_size_min: Optional[int] = None
    company_size_max: Optional[int] = None
    revenue_min: Optional[float] = None
    revenue_max: Optional[float] = None
    technologies: List[str] = []
    exclude_industries: List[str] = []
    geographic_regions: List[str] = []


class ClientContext(BaseModel):
    """Complete client context from Supabase."""
    client_id: str
    client_name: str
    pci: ClientPCI
    personas: List[Dict[str, Any]] = []
    competitors: List[Dict[str, Any]] = []
    case_studies: List[Dict[str, Any]] = []


class SupabaseClient:
    """
    Supabase client for context loading.

    Usage:
        client = SupabaseClient()
        context = client.load_client_context("uuid-client-123")
    """

    def __init__(
        self,
        supabase_url: Optional[str] = None,
        supabase_key: Optional[str] = None
    ):
        """
        Initialize Supabase client.

        Args:
            supabase_url: Supabase project URL (or SUPABASE_URL env var)
            supabase_key: Supabase anon key (or SUPABASE_KEY env var)
        """
        self.supabase_url = supabase_url or os.getenv("SUPABASE_URL")
        self.supabase_key = supabase_key or os.getenv("SUPABASE_KEY")

        # Try importing supabase
        try:
            from supabase import create_client, Client

            if not self.supabase_url or not self.supabase_key:
                raise ValueError(
                    "Supabase credentials required. "
                    "Set SUPABASE_URL and SUPABASE_KEY env vars."
                )

            self.client: Client = create_client(self.supabase_url, self.supabase_key)
            self.enabled = True

        except ImportError:
            # Supabase not installed - use mock data
            self.client = None
            self.enabled = False

    def load_client_context(self, client_id: str) -> ClientContext:
        """
        Load complete client context from Supabase.

        Args:
            client_id: Client UUID

        Returns:
            ClientContext with PCI, personas, competitors, case studies
        """
        if not self.enabled:
            # Return mock data for testing
            return self._get_mock_context(client_id)

        try:
            # Load client info
            client_response = self.client.table("clients").select("*").eq("id", client_id).execute()

            if not client_response.data:
                raise ValueError(f"Client {client_id} not found")

            client_data = client_response.data[0]

            # Load personas
            personas_response = self.client.table("personas").select("*").eq("client_id", client_id).execute()
            personas = personas_response.data or []

            # Load competitors
            competitors_response = self.client.table("competitors").select("*").eq("client_id", client_id).execute()
            competitors = competitors_response.data or []

            # Load case studies
            case_studies_response = self.client.table("case_studies").select("*").eq("client_id", client_id).execute()
            case_studies = case_studies_response.data or []

            # Parse PCI
            pci_data = client_data.get("pci", {})
            pci = ClientPCI(**pci_data) if pci_data else ClientPCI()

            return ClientContext(
                client_id=client_id,
                client_name=client_data.get("name", "Unknown Client"),
                pci=pci,
                personas=personas,
                competitors=competitors,
                case_studies=case_studies
            )

        except Exception as e:
            # Fallback to mock data on error
            return self._get_mock_context(client_id)

    def _get_mock_context(self, client_id: str) -> ClientContext:
        """Get mock context for testing when Supabase unavailable."""
        return ClientContext(
            client_id=client_id,
            client_name="Mock Client",
            pci=ClientPCI(
                industry=["SaaS", "Technology"],
                company_size_min=50,
                company_size_max=500,
                technologies=["Salesforce", "HubSpot"],
                geographic_regions=["North America", "Europe"]
            ),
            personas=[
                {
                    "title": "VP Sales",
                    "pain_points": ["Manual prospecting", "Low conversion rates"],
                    "signals": ["Hiring SDRs", "Using LinkedIn Sales Nav"]
                },
                {
                    "title": "Head of Marketing",
                    "pain_points": ["Attribution tracking", "Lead quality"],
                    "signals": ["Running paid ads", "Large marketing budget"]
                }
            ],
            competitors=[
                {
                    "name": "Competitor A",
                    "product_category": "CRM Software"
                },
                {
                    "name": "Competitor B",
                    "product_category": "Sales Automation"
                }
            ],
            case_studies=[
                {
                    "result": "Increased pipeline by 3x in 6 months",
                    "metrics": {"pipeline_growth": 300, "time_months": 6}
                }
            ]
        )

    def filter_by_pci(
        self,
        contact: Dict[str, Any],
        client_id: str
    ) -> Dict[str, Any]:
        """
        Filter contact by Profil Client Ideal.

        Args:
            contact: Contact data with company_name, industry, employees, etc.
            client_id: Client UUID for loading PCI

        Returns:
            Dict with match (bool), score (0-1), reason (str)
        """
        context = self.load_client_context(client_id)
        pci = context.pci

        score = 0.0
        reasons = []

        # Industry match (40% weight)
        contact_industry = contact.get("industry", "").lower()
        if pci.industry:
            industry_match = any(
                ind.lower() in contact_industry or contact_industry in ind.lower()
                for ind in pci.industry
            )
            if industry_match:
                score += 0.4
                reasons.append("Industry match")
            else:
                reasons.append("Industry mismatch")

        # Company size (30% weight)
        contact_employees = contact.get("employees") or contact.get("company_size")
        if contact_employees and pci.company_size_min and pci.company_size_max:
            try:
                employees = int(contact_employees)
                if pci.company_size_min <= employees <= pci.company_size_max:
                    score += 0.3
                    reasons.append("Company size in range")
                else:
                    reasons.append(f"Company size out of range ({employees} not in {pci.company_size_min}-{pci.company_size_max})")
            except (ValueError, TypeError):
                pass

        # Technologies (20% weight)
        contact_tech = contact.get("technologies", [])
        if pci.technologies and contact_tech:
            tech_match = any(tech in contact_tech for tech in pci.technologies)
            if tech_match:
                score += 0.2
                reasons.append("Technology stack match")

        # Geographic regions (10% weight)
        contact_region = contact.get("region", "").lower()
        if pci.geographic_regions and contact_region:
            region_match = any(
                region.lower() in contact_region
                for region in pci.geographic_regions
            )
            if region_match:
                score += 0.1
                reasons.append("Geographic match")

        # Exclude industries (automatic rejection)
        if pci.exclude_industries:
            excluded = any(
                exc.lower() in contact_industry
                for exc in pci.exclude_industries
            )
            if excluded:
                score = 0.0
                reasons = ["Industry excluded by PCI"]

        # Determine match
        match = score >= 0.6  # 60% threshold

        return {
            "match": match,
            "score": round(score, 2),
            "reason": " | ".join(reasons)
        }

    def cache_scraping(
        self,
        url: str,
        content: str,
        ttl_days: int = 7
    ) -> bool:
        """
        Cache scraped website content in Supabase.

        Args:
            url: Website URL
            content: Scraped markdown content
            ttl_days: Time-to-live in days

        Returns:
            True if cached successfully
        """
        if not self.enabled:
            return False

        try:
            expires_at = datetime.now().isoformat()

            self.client.table("scraping_cache").upsert({
                "url": url,
                "content": content,
                "scraped_at": datetime.now().isoformat(),
                "expires_at": expires_at
            }).execute()

            return True

        except Exception:
            return False

    def get_cached_scraping(self, url: str) -> Optional[str]:
        """
        Get cached scraped content from Supabase.

        Args:
            url: Website URL

        Returns:
            Cached content or None if not found/expired
        """
        if not self.enabled:
            return None

        try:
            response = self.client.table("scraping_cache").select("content, expires_at").eq("url", url).execute()

            if not response.data:
                return None

            data = response.data[0]
            expires_at = datetime.fromisoformat(data["expires_at"])

            if datetime.now() > expires_at:
                # Expired
                return None

            return data["content"]

        except Exception:
            return None
